﻿using System;
using System.Windows.Forms;

namespace DesafioDV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnGerarDV_Click(object sender, EventArgs e)
        {
            Matricula matricula = new Matricula();
            string conteudo = matricula.gerarDV();
            MessageBox.Show(conteudo);
        }

        private void btnValidarMat_Click(object sender, EventArgs e)
        {
            Matricula matricula = new Matricula();
            string conteudo = matricula.verificarDV();
            MessageBox.Show(conteudo);
        }
    }
}
