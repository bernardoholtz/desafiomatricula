﻿namespace DesafioDV
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGerarDV = new System.Windows.Forms.Button();
            this.btnValidarMat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGerarDV
            // 
            this.btnGerarDV.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGerarDV.Location = new System.Drawing.Point(69, 60);
            this.btnGerarDV.Name = "btnGerarDV";
            this.btnGerarDV.Size = new System.Drawing.Size(146, 47);
            this.btnGerarDV.TabIndex = 0;
            this.btnGerarDV.Text = "Gerar Dígito Verificador";
            this.btnGerarDV.UseVisualStyleBackColor = false;
            this.btnGerarDV.Click += new System.EventHandler(this.btnGerarDV_Click);
            // 
            // btnValidarMat
            // 
            this.btnValidarMat.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnValidarMat.Location = new System.Drawing.Point(69, 134);
            this.btnValidarMat.Name = "btnValidarMat";
            this.btnValidarMat.Size = new System.Drawing.Size(146, 46);
            this.btnValidarMat.TabIndex = 1;
            this.btnValidarMat.Text = "Verificar Matrícula";
            this.btnValidarMat.UseVisualStyleBackColor = false;
            this.btnValidarMat.Click += new System.EventHandler(this.btnValidarMat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnValidarMat);
            this.Controls.Add(this.btnGerarDV);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Desafio DV";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGerarDV;
        private System.Windows.Forms.Button btnValidarMat;
    }
}

