﻿using System;
using System.IO;

namespace DesafioDV
{
    public class Matricula
    {
        public string gerarDV() {
            File.Delete(AppDomain.CurrentDomain.BaseDirectory + "matriculasComDV.txt");
            StreamReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "matriculasSemDV.txt");
            string linha = reader.ReadLine();

            string conteudo = "";
            while (linha != null) {
               conteudo += calcularDV(linha,"G") + "\n";
               linha = reader.ReadLine();
            }
            return conteudo;
        }

        

        public string verificarDV()
        {
            File.Delete(AppDomain.CurrentDomain.BaseDirectory + "matriculasVerificadas.txt");
            StreamReader reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "matriculasParaVerificar.txt");
            string linhaDV = reader.ReadLine();
            string linha = linhaDV.Substring(0, 4);

            string conteudo = "";
            while (linhaDV != null)
            {

                linha = calcularDV(linha, "V");
                linhaDV += (linha == linhaDV ? " verdadeiro" : " falso");
                using (StreamWriter writer = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "matriculasVerificadas.txt", true))
                {
                   writer.WriteLine(linhaDV);

                }
                
                conteudo += linhaDV + "\n";
                linhaDV = reader.ReadLine();
                if (linhaDV != null) linha = linhaDV.Substring(0, 4);

            }
            return conteudo;
        }

        public string calcularDV(string linha, string parametro)
        {
            char[] nums = new char[linha.Length];
            using (StringReader sr = new StringReader(linha))
            {
                sr.Read(nums, 0, linha.Length);
                if (linha.Length > 4) return "Matrícula inválida (contém mais de 4 caracteres)";
                int total = 0;
                for (int i = 0; i < linha.Length; i++)
                {
                    try
                    {
                        int numero = int.Parse(nums[i].ToString());
                        total += numero * ((linha.Length + 1) - i);
                    }
                    catch(Exception e)
                    {
                        return "Matrícula com caracteres inválidos";
                    }
                    
                    
                }
                total = total % 16;
                string hex = total.ToString("X");
                if (parametro == "G")
                {
                    using (StreamWriter writer = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "matriculasComDV.txt", true))
                    {
                        writer.WriteLine(linha + "-" + hex);
                        
                    }
                }

                return linha + "-" + hex;
            }
        }

        public int calcular(int num)
        {
            return num + 1;
        }
    }
}
