﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DesafioDV;

namespace TesteDV
{
    [TestClass]
    public class MatriculaTeste
    {
        [TestMethod]
        public void testarMatricula()
        {
            
            Matricula matricula = new Matricula();
            Assert.AreEqual(matricula.calcularDV("9876", "G"), "9876-E");

        }

        [TestMethod]
        public void testarTotalCaracteres()
        {
            
            Matricula matricula = new Matricula();
            Assert.AreEqual(matricula.calcularDV("18760", "G"), "Matrícula inválida (contém mais de 4 caracteres)");

        }

        [TestMethod]
        public void testarCaracterInvalido()
        {

            Matricula matricula = new Matricula();
            Assert.AreEqual(matricula.calcularDV("9P70", "G"), "Matrícula com caracteres inválidos");

        }


    }
}
