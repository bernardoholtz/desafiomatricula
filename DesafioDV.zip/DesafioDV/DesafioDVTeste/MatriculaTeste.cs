﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DesafioDVTeste
{
    [TestClass]
    public class MatriculaTeste
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
